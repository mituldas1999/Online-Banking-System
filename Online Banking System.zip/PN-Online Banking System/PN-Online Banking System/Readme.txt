Admin:
username:admin
password:password123

Users:
user:ross
password:password

user:racheal
password:password

user:joey
password:password